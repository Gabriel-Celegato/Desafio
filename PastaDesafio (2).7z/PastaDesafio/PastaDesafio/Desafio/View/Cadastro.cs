﻿using Desafio.Util;
using Microsoft.Data.SqlClient;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace Desafio
{
    public partial class Cadastro : Form

    {


        PrivateFontCollection fontes = new PrivateFontCollection();
        public Cadastro()
        {
            InitializeComponent();
            fontes.AddFontFile(@"NovaPasta\Minecrafter.Reg.ttf"); // caminho relativo


            label1.Font = ChamarFonte(20);
            label2.Font = ChamarFonte(20);
            label3.Font = ChamarFonte(12);
            label4.Font = ChamarFonte(12);
            textBox1.Font = ChamarFonte(12);
            textBox2.Font = ChamarFonte(12);
            textBox3.Font = ChamarFonte(12);
            textBox4.Font = ChamarFonte(12);
            button1.Font = ChamarFonte(12);

            ArredondarPictureBox(pictureBox1, 70);

        }
        private Font ChamarFonte(float tamanhoFonte)
        {
            return new Font(fontes.Families[0], tamanhoFonte, FontStyle.Regular);
        }

        private void ArredondarPictureBox(PictureBox pic, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            path.AddArc(0, 0, radius, radius, 180, 90);
            path.AddArc(pic.Width - radius, 0, radius, radius, 270, 90);
            path.AddArc(pic.Width - radius, pic.Height - radius, radius, radius, 0, 90);
            path.AddArc(0, pic.Height - radius, radius, radius, 90, 90);
            path.CloseFigure();

            pic.Region = new Region(path);
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "") { MessageBox.Show("Por favor, insira um nome."); return; }
            else if (textBox2.Text == "") { MessageBox.Show("Por favor, insira um email."); return; }
            else if (textBox3.Text == "") { MessageBox.Show("Por favor, insira uma senha."); return; }
            else if (textBox3.Text != textBox4.Text) { MessageBox.Show("As senhas não coincidem."); return; }

            else
            {

                string insertQuery = @"INSERT INTO Pessoas(nome, Email, senha) VALUES (@Nome, @email, @Senha)";

                using (SqlConnection connectionb = new SqlConnection(Util.util.conexao))
                using (SqlCommand commandB = new SqlCommand(insertQuery, connectionb))
                {
                    connectionb.Open();

                    commandB.Parameters.AddWithValue("@Nome", textBox1.Text);
                    commandB.Parameters.AddWithValue("@Email", textBox2.Text);
                    commandB.Parameters.AddWithValue("@Senha", textBox3.Text);
                    commandB.ExecuteNonQuery();


                }

                MessageBox.Show("Cadastro realizado com sucesso!");
                this.Hide();
            }
        }

        private void Cadastro_Load(object sender, EventArgs e)
        {

        }
    }
}
