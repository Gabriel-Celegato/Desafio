﻿create table Produtos (

product_id int identity primary key not null,
product_name varchar(100) not null,
unit_price decimal(10,2) not null,
quantity_per_unit int not null,
unit_in_stock int not null,
discontinued bit not null


);

create table purchase_item( 
	
	purchase_item_id int identity primary key not null,
	product_id int not null,
	quantity int not null,
	unit_price decimal(10,2) not null,

);

create table Purchases (

	purchase_id int identity primary key not null,
	purchase_date datetime not null,
	customer_name varchar(100) not null,
	total_amount decimal(10,2) not null
);

create table category(

	category_id int identity primary key not null,
	nome varchar(60),
	description varchar(255),
	parent_category_id int null
	
);

select * from Produtos;