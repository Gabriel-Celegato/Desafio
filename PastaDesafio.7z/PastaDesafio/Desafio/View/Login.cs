using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;


namespace Desafio
{
    public partial class Login : Form
    {
        PrivateFontCollection fontes = new PrivateFontCollection();

        public Login()
        {
            InitializeComponent();

            // --- Carregar a fonte personalizada ---
            fontes.AddFontFile(@"NovaPasta\Minecrafter.Reg.ttf"); // caminho relativo


            label1.Font = ChamarFonte(20);
            label2.Font = ChamarFonte(20);
            textBox1.Font = ChamarFonte(12);
            textBox2.Font = ChamarFonte(12);
            button1.Font = ChamarFonte(12);
            // --------------------------------------

            ArredondarPictureBox(pictureBox1, 70);
            AplicarEstiloArredondado(textBox1, 12, Color.Transparent, Color.White);
            AplicarEstiloArredondado(textBox2, 12, Color.Transparent, Color.White);
        }

        private Font ChamarFonte(float tamanhoFonte)
        {
            return new Font(fontes.Families[0], tamanhoFonte, FontStyle.Regular);
        }

        private void ArredondarPictureBox(PictureBox pic, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            path.AddArc(0, 0, radius, radius, 180, 90);
            path.AddArc(pic.Width - radius, 0, radius, radius, 270, 90);
            path.AddArc(pic.Width - radius, pic.Height - radius, radius, radius, 0, 90);
            path.AddArc(0, pic.Height - radius, radius, radius, 90, 90);
            path.CloseFigure();

            pic.Region = new Region(path);
        }

        public class ButtonRedondo : Button
        {
            protected override void OnPaint(PaintEventArgs e)
            {
                GraphicsPath path = new GraphicsPath();
                path.AddArc(0, 0, 20, 20, 180, 90);
                path.AddArc(this.Width - 20, 0, 20, 20, 270, 90);
                path.AddArc(this.Width - 20, this.Height - 20, 20, 20, 0, 90);
                path.AddArc(0, this.Height - 20, 20, 20, 90, 90);
                path.CloseFigure();

                this.Region = new Region(path);
                base.OnPaint(e);
            }
        }

        public static void AplicarEstiloArredondado(TextBox txt, int raio, Color corBorda, Color corFundo)
        {
            GraphicsPath path = new GraphicsPath();
            path.AddArc(0, 0, raio, raio, 180, 90);
            path.AddArc(txt.Width - raio, 0, raio, raio, 270, 90);
            path.AddArc(txt.Width - raio, txt.Height - raio, raio, raio, 0, 90);
            path.AddArc(0, txt.Height - raio, raio, raio, 90, 90);
            path.CloseFigure();

            txt.Region = new Region(path);
            txt.BorderStyle = BorderStyle.None;
            txt.BackColor = corFundo;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.PasswordChar == '*')
                textBox2.PasswordChar = '\0';
            else
                textBox2.PasswordChar = '*';
        }
    }
}
