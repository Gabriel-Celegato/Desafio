﻿using Desafio.Util;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms;


namespace Desafio
{
    public partial class Produtos : Form
    {

        PrivateFontCollection fontes = new PrivateFontCollection();

        public Produtos()
        {
            InitializeComponent();

            ShowTable();

            // --- Carregar a fonte personalizada ---
            fontes.AddFontFile(@"NovaPasta\Minecrafter.Reg.ttf"); // caminho relativo


            textBox1.MaxLength = 100;
 

            label1.Font = ChamarFonte(12);
            label2.Font = ChamarFonte(12);
            label3.Font = ChamarFonte(12);
            label4.Font = ChamarFonte(12);
            label5.Font = ChamarFonte(12);
            button1.Font = ChamarFonte(12);

            ArredondarPictureBox(pictureBox1, 70);
        }

        private void ArredondarPictureBox(PictureBox pic, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            path.AddArc(0, 0, radius, radius, 180, 90);
            path.AddArc(pic.Width - radius, 0, radius, radius, 270, 90);
            path.AddArc(pic.Width - radius, pic.Height - radius, radius, radius, 0, 90);
            path.AddArc(0, pic.Height - radius, radius, radius, 90, 90);
            path.CloseFigure();

            pic.Region = new Region(path);
        }

        private Font ChamarFonte(float tamanhoFonte)
        {
            return new Font(fontes.Families[0], tamanhoFonte, FontStyle.Regular);
        }


        private void Produtos_Load(object sender, EventArgs e)
        {

        }

        private void ShowTable()
        {
            string insertQuery = @"select * from Produtos";

            using (SqlConnection connectionb = new SqlConnection(Util.util.conexao))
            using (SqlCommand commandB = new SqlCommand(insertQuery, connectionb))
            {
                connectionb.Open();


                commandB.ExecuteNonQuery();


                using (SqlDataAdapter da = new SqlDataAdapter(commandB))
                {
                    DataTable dataTable = new DataTable();
                    da.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Por favor, insira o nome do produto.");
                return;
            }
            else if (numericUpDown1.Value <= 0 && numericUpDown1.Value >  100000)
            {
                MessageBox.Show("Por favor, insira o preço unitário válido, ex: 100");
                return;
            }
            else if (numericUpDown2.Value <= 1 && numericUpDown2.Value > 100)
            {
                MessageBox.Show("Por favor, insira a quantidade do produto na compra válido ( menor de 100 )");
                return;
            }
            else if(numericUpDown3.Value > 100000000)
            {
                MessageBox.Show("Insira um valor válido menor de 100m");
            }
            else if (textBox5.Text == "")
            {
                MessageBox.Show("Por favor, insira se está disponível. ( 1 = sim, 0 = não )");
                return;

            }
            else
            {
                string insertQuery = @"insert into Produtos (product_name, unit_price, quantity_per_unit , unit_in_stock, discontinued ) values (@Nome, @PrecoUnitario,@QuantidadePorUnidade, @Quantidade, @discontinued )";
                using (SqlConnection connectionb = new SqlConnection(Util.util.conexao))
                using (SqlCommand commandB = new SqlCommand(insertQuery, connectionb))
                {
                    connectionb.Open();
                    commandB.Parameters.AddWithValue("@Nome", textBox1.Text);
                    commandB.Parameters.AddWithValue("@PrecoUnitario", numericUpDown1.Value);
                    commandB.Parameters.AddWithValue("@QuantidadePorUnidade", numericUpDown2.Value);
                    commandB.Parameters.AddWithValue("@Quantidade", numericUpDown3.Value);
                    commandB.Parameters.AddWithValue("@discontinued", textBox5.Text);
                    commandB.ExecuteNonQuery();
                    ShowTable();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
           Desafio.View.Pessoas pessoas = new Desafio.View.Pessoas();
              pessoas.ShowDialog();
        }
    }
}
