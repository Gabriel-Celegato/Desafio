﻿create table Pessoas (

ID int identity primary key not null,
Nome varchar(100) not null,
Email varchar(100) not null,
Senha varchar(100) not null


);

select * from Pessoas;